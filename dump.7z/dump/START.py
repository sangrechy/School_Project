##################################-IMPORTING MODULE AND PACKAGES-###########################
import mysql.connector as sql
import time

#######################################-CONNECTING TO MYSQL-################################
user='root'#{user_name}
password=#{user_password}
def CONNECT():
    connection_object=sql.connect(host='localhost',user=user,passwd=password)
    return connection_object
connection_object=CONNECT()
if connection_object.is_connected():
    print('SUCCESSFULLY CONNECTED TO MYSQL..')
else:
    print('ERROR CONNECTING TO MYSQL, PLEASE TRY AGAIN')
    connection_object=CONNECT()
    if connection_object.is_connected():
        print('SUCCESSFULLY CONNECTED TO MYSQL..')
    else:
        print('ERROR CONNECTING TO MYSQL, PLEASE TRY LATER')
        time.sleep(20)
        exit()
cursor_object=connection_object.cursor()

#######################################-CREATING DATABASE AND TABLES-######################
#CREATING DATABASES AND ACCESSING IT
cursor_object.execute('CREATE DATABASE IF NOT EXISTS MOVIES;')
cursor_object.execute('USE MOVIES;')
x='''INSERT INTO USER_INFO (USER_ID, USER_NAME, AGE, GENDER, FAVORITE_ACTOR)
VALUES
    (1, 'Emma', 18, 'FEMALE', 'Tom Hanks'),
    (2, 'Liam', 42, 'MALE', 'Meryl Streep'),
    (3, 'Olivia', 33, 'FEMALE', 'Denzel Washington'),
    (4, 'Noah', 55, 'MALE', 'Julia Roberts'),
    (5, 'Sophia', 26, 'FEMALE', 'Brad Pitt'),
    (6, 'Elijah', 67, 'MALE', 'Angelina Jolie'),
    (7, 'Ava', 12, 'FEMALE', 'Leonardo DiCaprio'),
    (8, 'Jackson', 40, 'MALE', 'Jennifer Lawrence'),
    (9, 'Mia', 8, 'FEMALE', 'Will Smith'),
    (10, 'William', 70, 'MALE', 'Sandra Bullock'),
    (11, 'Sophia', 71, 'FEMALE', 'George Clooney'),
    (12, 'Michael', 73, 'MALE', 'Meryl Streep'),
    (13, 'Olivia', 77, 'FEMALE', 'Tom Hanks'),
    (14, 'James', 82, 'MALE', 'Julia Roberts'),
    (15, 'Lily', 85, 'FEMALE', 'Denzel Washington'),
    (16, 'Noah', 88, 'MALE', 'Angelina Jolie'),
    (17, 'Emily', 90, 'FEMALE', 'Brad Pitt'),
    (18, 'Liam', 92, 'MALE', 'Jennifer Lawrence'),
    (19, 'Harper', 95, 'FEMALE', 'Will Smith'),
    (20, 'Jackson', 99, 'MALE', 'Leonardo DiCaprio'),
    (21, 'Aiden', 47, 'MALE', 'Sandra Bullock'),
    (22, 'Isabella', 19, 'FEMALE', 'George Clooney'),
    (23, 'Oliver', 52, 'MALE', 'Meryl Streep'),
    (24, 'Charlotte', 35, 'FEMALE', 'Tom Hanks'),
    (25, 'Henry', 58, 'MALE', 'Julia Roberts'),
    (26, 'Grace', 62, 'FEMALE', 'Denzel Washington'),
    (27, 'William', 65, 'MALE', 'Brad Pitt'),
    (28, 'Sophia', 35, 'FEMALE', 'Angelina Jolie'),
    (29, 'Michael', 52, 'MALE', 'Leonardo DiCaprio'),
    (30, 'Mia', 60, 'FEMALE', 'Sandra Bullock');'''
cursor_object.execute(x)
connection_object.commit()


    
    
    
    
    
    
    
        
    



    
    
      
    
    
    
    

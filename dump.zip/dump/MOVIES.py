
##################################-IMPORTING MODULE AND PACKAGES-###########################
import mysql.connector as sql
import time
#######################################-CONNECTING TO MYSQL-################################
user='root'#{user_name}
password=#{user_password}
def CONNECT():
    connection_object=sql.connect(host='localhost',user=user,passwd=password)
    return connection_object
connection_object=CONNECT()
if connection_object.is_connected():
    print('SUCCESSFULLY CONNECTED TO MYSQL..')
else:
    print('ERROR CONNECTING TO MYSQL, PLEASE TRY AGAIN')
    connection_object=CONNECT()
    if connection_object.is_connected():
        print('SUCCESSFULLY CONNECTED TO MYSQL..')
    else:
        print('ERROR CONNECTING TO MYSQL, PLEASE TRY LATER')
        time.sleep(20)
        exit()
cursor_object=connection_object.cursor()

#########################################-CREATING DATABASE AND TABLES-######################
#CREATING DATABASES AND ACCESSING IT
cursor_object.execute('CREATE DATABASE IF NOT EXISTS MOVIES;')
cursor_object.execute('USE MOVIES;')


#CREATING TABLES:-
#TABLES:-
#1.MOVIES_INFO TABLE: CONTAINS INFORMATION ABOUT MOVIES (i.e)MOVIE CODE, MOVIES NAME,YEAR RELEASED,
#  MOVIE GENERE,DURATION, ACTORS NAME, IMDB RATING.
#2.MOVIES_ANALYSING TABLE: CONTAINS DATA OF MOVIES SUCH AS WHICH AGE CATAGEROY PEOPLE WOULD
#  WATCH, WHETHER ITS MALE OR FEMALE.
#3.USER_INFO TABLE: CONTAINS INFORMATION OF USER SUCH AS USER ID, NAME, AGE, GENDER,
#  FAVORITE ACTOR. 
#4.USER_ANALYSING TABLE: CONTAINS STATSTICS OF USER ABOUT HIS/HER PREFERENCES IN GENERE.
#5.GENERE_ANALYSING TABLE: CONTAINS STATSTICS OF MOVIES GENERE ACCORDING TO AGE.
#6.RENT_HISTORY: CONTAINS USER ID ,USER NAME,MOVIE CODE,MOVIE NAME ,RENTED DATE,DUE DATE ,PAYMENT STATUS.

tempvar='CREATE TABLE IF NOT EXISTS MOVIE_INFO(MOVIE_CODE INT PRIMARY KEY,MOVIE_NAME VARCHAR(20),\
YEAR_RELEASED YEAR(4),GENERE ENUM("ACTION", "THRILLER", "HORROR", "ANIMATION", "FAMILY", "FANTASY",\
"COMEDY", "SCI_FI"),ACTORS VARCHAR(50),DURATION TIME,IMDB_RATING FLOAT);'
cursor_object.execute(tempvar)

tempvar='CREATE TABLE IF NOT EXISTS MOVIE_ANALYSING(MOVIE_CODE INT REFERENCES MOVIE_INFO(MOVIE_CODE),\
1_5 INT, 5_10 INT, 10_15 INT, 15_20 INT, 20_25 INT, 25_30 INT, 30_40 INT, 40_50 INT, 50_70 INT,\
70PLUS INT,MALE INT,FEMALE INT);'
cursor_object.execute(tempvar)

tempvar='CREATE TABLE IF NOT EXISTS USER_INFO(USER_ID INT PRIMARY KEY,USER_NAME VARCHAR(20),AGE INT,\
GENDER ENUM("MALE","FEMALE","NULL"),FAVORITE_ACTOR VARCHAR(50));'
cursor_object.execute(tempvar)

tempvar='CREATE TABLE IF NOT EXISTS USER_ANALYSING(USER_ID INT REFERENCES USER_INFO(USER_ID),SCI_FI INT,\
ACTION INT, THRILLER INT, HORROR INT, ANIMATION INT, FAMILY INT, FANTASY INT, COMEDY INT,MALE INT,FEMALE INT);'
cursor_object.execute(tempvar)
############
tempvar='CREATE TABLE IF NOT EXISTS GENERE_ANALYSING(GENERE VARCHAR(20) PRIMARY KEY,\
1_5 INT, 5_10 INT, 10_15 INT, 15_20 INT, 20_25 INT, 25_30 INT, 30_40 INT, 40_50 INT, 50_70 INT,\
70PLUS INT,MALE INT,FEMALE INT);'
cursor_object.execute(tempvar)

tempvar='CREATE TABLE IF NOT EXISTS RENT_HISTORY(USER_ID INT REFERENCES USER_INFO(USER_ID),USER_NAME\
VARCHAR(20) REFERENCES USER_INFO(USER_NAME),MOVIE_CODE INT REFERENCES MOVIE_INFO(MOVIE_CODE),\
MOVIE_NAME VARCHAR(20) REFERENCES MOVIE_INFO(MOVIE_NAME)RENTED_DATE DATE, DUE_DATE DATE,PAYMENT_STATUS \
("EXPIRED","DUE","PAYED"));'
cursor_object.execute(tempvar)


###################################################START#########################################################
username=input('ENTER THE USER NAME:')
tempvar=('SELECT USER_ID FROM USER_INFO WHERE USER_NAME="{username}" ;').format(username=username)
cursor_object.execute(tempvar)
userexists=cursor_object.fetchone()
if userexists==None:
    print('WELCOME ITS SEEMS LIKE YOU ARE NEW TO OUR SHOP..LETS CREATE AN ACCOUNT FOR YOU')
    actor=[]##################################update
    age=int(input('YOUR AGE:'))
    gender=input('ARE YOU MALE OR FEMALE:').lower()
    print(gender)
    if not(gender ==  'male' or 'female'):
       gender='NULL'
    print(gender)
    fav=input('YOUR FAVORITE ACTOR')
    fav=fav.split()
    if any(x in fav for x in actor):
        fav=str(list(set(fav) & set(actor))).replace('[','').replace(']','')
        print('I KNOW ABOUT',fav.upper())
    else:
        print('SORRY I DONT KNOW ABOUT THEM')
        fav=None 
    tempvar='SELECT COUNT(*)FROM USER_INFO;'
    cursor_object.execute(tempvar)
    userid=userexists=cursor_object.fetchone()[0]+1
    tempvar=('INSERT INTO USER_INFO VALUES({userid},"{username}",{age},"{gender}","{fav}")')\
             .format(userid=userid,username=username,age=age,gender=gender.upper(),fav=fav)
    cursor_object.execute(tempvar)
    connection_object.commit()
    print(('YOUR USERNAME:{username} \n     USERID:{userid}').format(username=username,userid=userid))
tempvar=('SELECT USER_ID FROM USER_INFO WHERE USER_NAME="{username}" ;').format(username=username)
cursor_object.execute(tempvar)
userid=userexists=cursor_object.fetchone()[0]
varuserid=int(input('ENTER YOUR ID:'))
if varuserid==userid:
    print('WELCOME',username.upper())
else:
    print('WRONG USER ID..TRY AGAIN')
    varuserid=int(input('ENTER YOUR ID:'))
    if varuserid==userid:
        print('WELCOME',username.upper())
    else:
        print('WRONG USER ID..TRY LATER')
        time.sleep(5)
        exit()
        











